/**
 * 
 */
function confirmar(idcon){
	let resposta = confirm("Confirma a exlusão desta avaliação?")
	if(resposta === true){
		//alert(idcon)
		window.location.href = "delete?idcon=" + idcon
	}
}