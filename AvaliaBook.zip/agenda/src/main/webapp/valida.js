function validar(){
	 
	 
    let email = frmContato.email.value
    let senha = frmContato.senha.value
    
    if(email === ""){
        alert('Preencha o Email')
        frmContato.email.focus()
        return false
    } 

    if (senha === ""){
        alert('Preencha a Senha')
        frmContato.senha.focus()
        return false
    }
    else{
        window.location.href = 'comum.jsp'
    }
    }


function validarcadastro(){
	
	  let email = frmContato.email.value
    let senha = frmContato.senha.value
    
    if(email === ""){
        alert('Preencha o Email')
        frmContato.email.focus()
        return false
    } 

    if (senha === ""){
        alert('Preencha a Senha')
        frmContato.senha.focus()
        return false
    }
    else{
        window.location.href = 'inicio.html'
    }
    }

